<?php
//MySQL 연결
$connect = mysqli_connect("localhost","kim","crc503","opendesign");
mysqli_query($connect, "set names utf8");
$seq = $_POST[SEQ];
//query문 시작
//중복 검사
$query = mysqli_query($connect,"UPDATE t_design_work SET del_flag='N' WHERE seq='{$seq}'");
echo "OK";
?>