<?php
//MySQL 연결

session_start();
if(!$_SESSION['id']){
    ?>
    <script>
        alert('1로그인 정보가 없는 상태입니다.');
        history.back();
    </script>
    <?php
}

$connect = mysqli_connect("localhost","kim","crc503","opendesign");
mysqli_query($connect, "set names utf8");
$seq = $_POST[SEQ];
$type = $_POST[TYPE];
//query문 시작
//중복 검사
$query = mysqli_query($connect,"DELETE FROM t_stat_activities WHERE target_seq='{$seq}' AND target_type='{$type}'");
echo "OK";
?>