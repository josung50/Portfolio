
<script>
    $(document).on("click","#AlarmList",function(){
        location.replace("./listAlarm.php");
    });
    $(document).on("click","#CategoryList",function(){
        location.replace("./listCategory.php");
    });
    $(document).on("click","#DesignPreviewList",function(){
        location.replace("./listDesignPreview.php");
    });
    $(document).on("click","#DesignList",function(){
        location.replace("./listDesign.php");
    });
    $(document).on("click","#DesignCategoryList",function(){
        location.replace("./listDesignCategory.php");
    });
    $(document).on("click","#DesignCommentList",function(){
        location.replace("./listDesignComment.php");
    });
    $(document).on("click","#DesignFileList",function(){
        location.replace("./listDesignFile.php");
    });
    $(document).on("click","#DesignLikeList",function(){
        location.replace("./listDesignLike.php");
    });
    $(document).on("click","#MemberList",function(){
        location.replace("./listMember.php");
    });
    $(document).on("click","#MemberCategoryList",function(){
        location.replace("./listMemberCategory.php");
    });
    $(document).on("click","#OrderList",function(){
        location.replace("./listOrder.php");
    });
    $(document).on("click","#ProjectGroupList",function(){
        location.replace("./listProjectGroup.php");
    });
    $(document).on("click","#ProjectGroupProjectList",function(){
        location.replace("./listProjectGroupProject.php");
    });
    $(document).on("click","#ProjectGroupProjectRequestList",function(){
        location.replace("./listProjectGroupProjectRequest.php");
    });
    $(document).on("click","#PointHistroyList",function(){
        location.replace("./listPoint.php");
    });
    $(document).on("click","#ProjectList",function(){
        location.replace("./listProject.php");
    });
    $(document).on("click","#ProjectCategoryList",function(){
        location.replace("./listProjectCategory.php");
    });
    $(document).on("click","#ProjectMemberList",function(){
        location.replace("./listProjectMember.php");
    });
    $(document).on("click","#ProjectSubjectList",function(){
        location.replace("./listProjectSubject.php");
    });
    $(document).on("click","#ProjectWorkList",function(){
        location.replace("./listProjectWork.php");
    });
    $(document).on("click","#ProjectWorkCommentList",function(){
        location.replace("./listProjectWorkComment.php");
    });
    $(document).on("click","#ProjectWorkLikeList",function(){
        location.replace("./listProjectWorkLike.php");
    });
    $(document).on("click","#ProjectWorkMemberList",function(){
        location.replace("./listProjectWorkMember.php");
    });
    $(document).on("click","#ProjectWorkVerList",function(){
        location.replace("./listProjectWorkVer.php");
    });
    $(document).on("click","#RequestList",function(){
        location.replace("./listRequest.php");
    });
    $(document).on("click","#RequestCategoryList",function(){
        location.replace("./listRequestCategory.php");
    });
    $(document).on("click","#RequestCommentList",function(){
        location.replace("./listRequestComment.php");
    });
    $(document).on("click","#RequestFileList",function(){
        location.replace("./listRequestFile.php");
    });
    $(document).on("click","#StatActivitiesList",function(){
        location.replace("./listStat.php");
    });
    $(document).on("click","#TalkList",function(){
        location.replace("./listTalk.php");
    });
    $(document).on("click","#ZipCodeList",function(){
        location.replace("./listZipCode.php");
    });

</script>
<button id="AlarmList">Alarm List(알림)</button>
<button id="CategoryList">Category List(카테고리)</button>
<button id="DesignPreviewList">Design Preview List(디자인소개이미지)</button>
<button id="DesignList" style="background-color: #f44336;">Design List(디자인작품)</button>
<button id="DesignCategoryList">Design Category List(디자인카테고리)</button>
<button id="DesignCommentList">Design Comment List(디자인작품댓글)</button>
<button id="DesignFileList">Design File List(디자인첨부파일)</button>
<button id="DesignLikeList">Design Like List(디자인찜)</button>
<button id="MemberList"style="background-color: #f44336;">Member List(회원)</button>
<button id="MemberCategoryList">Member Category List(회원카테고리)</button>
<button id="OrderList">Order List(구매)</button>
<button id="ProjectGroupList">Project Group List(프로젝트그룹)</button>
<button id="ProjectGroupProjectList">Project Group Project List(프로젝트그룹프로젝트)</button>
<button id="ProjectGroupProjectRequestList">Project Group Project Request List(프로젝트그룹프로젝트신청)</button>
<button id="PointHistroyList">Point History List(포인트가감이력)</button>
<button id="ProjectList">Project List(프로젝트)</button>
<button id="ProjectCategoryList">Project Category List(프로젝트카테고리)</button>
<button id="ProjectMemberList">Project Member List(프로젝트참여자)</button>
<button id="ProjectSubjectList">Project Subject List(프로젝트주제)</button>
<button id="ProjectWorkList" style="background-color: #f44336;">Project Work List(프로젝트작품)</button>
<button id="ProjectWorkCommentList">Project Work Comment List(프로젝트작품댓글)</button>
<button id="ProjectWorkLikeList">Project Work Like List(프로젝트작품찜)</button>
<button id="ProjectWorkMemberList">Project Work Member List(프로젝트작품참여자)</button>
<button id="ProjectWorkVerList">Project Work Ver List(프로젝트작품버전)</button>
<button id="RequestList">Request List(의뢰게시판)</button>
<button id="RequestCategoryList">Request Category List(게시판카테고리)</button>
<button id="RequestCommentList">Request Comment List(게시판댓글)</button>
<button id="RequestFileList">Request File List(게시판첨부이미지)</button>
<button id="StatActivitiesList"style="background-color: #f44336;">Stat Activities List(메인에 보여지는 디자인/디자이너)</button>
<button id="TalkList">Talk List(쪽지)</button>
<button id="ZipCodeList">Zip Code List(시/도 리스트)</button>

