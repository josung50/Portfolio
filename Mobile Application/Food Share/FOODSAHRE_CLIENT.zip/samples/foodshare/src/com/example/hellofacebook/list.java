package com.example.hellofacebook;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Layout;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.facebook.Profile;

import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by JSR on 2015-11-18.
 */
public class list extends Activity implements Spinner.OnItemSelectedListener {

    private Profile profile = Profile.getCurrentProfile(); // 페이스북 로그인 사용자 프로파일

    String[] foodstylelist2 = {"전체 ▼", "한식", "중식", "양식", "일식"};
    String[] arealist2 = {"전체 ▼", "서울", "경기"};
    String foodstyleInpo2=""; String areaInpo2="";
    static byte[] imageArr;
    ArrayList<Story> al = new ArrayList<Story>(); // 어뎁터 생성

    /* 추천버튼에 필요한 레이아웃 매칭 */
    TextView recommendText;
    Button closeButton;

    /* 프로그램 종료시 */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if(keyCode == KeyEvent.KEYCODE_BACK)
        {
            try {
                GlobalSocket.out.write("QUIT".getBytes());
                GlobalSocket.in.close();
                GlobalSocket.out.close();
                GlobalSocket.socket.close();
            } catch (IOException e) {
            }
            finally {
                finish();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       setContentView(R.layout.list);
        recommendText =  (TextView) findViewById(R.id.recommendText);
        closeButton =  (Button) findViewById(R.id.closeButton);


        // 스피너
        Spinner foodstyleListButton2 = (Spinner) findViewById(R.id.foodstylelist2);
        foodstyleListButton2.setOnItemSelectedListener(this); // 스피너에 아이템 클릭 시 실행될 리스너 foodstyle
        Spinner areaListButton2 = (Spinner) findViewById(R.id.arealist2);
        areaListButton2.setOnItemSelectedListener(this); // 스피너에 아이템 클릭 시 실행될 리스너 legion


         /* 어댑터 배열 객체 생성(this는 Context 메인 액티비티를 가리킴,
         * 안드로이드에 있는 어댑터 객체 에서 지원해주는 스피너 레이아웃,아이템 배열)
         * android는 안드로이드가 가지고 있는 전역 변수*/
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                this, R.layout.spinner_item , foodstylelist2);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 리스트 형태로 늘림
        foodstyleListButton2.setAdapter(adapter); // 어댑터 설정

        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(
                this,  R.layout.spinner_item , arealist2);
        adapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // 리스트 형태로 늘림
        areaListButton2.setAdapter(adapter3); // 어댑터 설정
    }
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch(parent.getId()) {
            case R.id.foodstylelist2:
                foodstyleInpo2 = foodstylelist2[position];
                break;
            case R.id.arealist2:
                areaInpo2 = arealist2[position];
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        switch (parent.getId()) {
            case R.id.foodstylelist2:
                foodstyleInpo2 = foodstylelist2[0];
                break;
            case R.id.arealist2:
                areaInpo2 = arealist2[0];
                break;
        }
    }
    // 스피너 끝

    // 추천 버튼
    public void recommendButton(View v) {

        recommendText.setVisibility(View.VISIBLE);
        closeButton.setVisibility(View.VISIBLE);

        try {
            // Ok싸인 까지
            GlobalSocket.out.write(("RECOMMEND/" + profile.getName() + "/").getBytes());
            byte[] instrA;
            String str = "";
            String str1 = "";

            while (GlobalSocket.bBufferLength <= 0) {
            }

            instrA = new byte[GlobalSocket.bBufferLength];
            instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
            str = new String(instrA, "CP949");
            GlobalSocket.bBufferLength = 0;
            GlobalSocket.dataSize = 0;

            recommendText.setText("How about eatting " + str + "?");

        }

        catch (IOException e) {
            System.out.println("bitmapErr: " + e);
        }
    }


    // 추천버튼 클릭 후 닫기버튼 누르면
    public void closeButton (View v) {
        recommendText.setVisibility(View.INVISIBLE);
        recommendText.setText("");
        closeButton.setVisibility(View.INVISIBLE);
    }


    // 검색 조건 설정 후 Search
    public void searchButton(View v) {

        // 전에 있던 리스트 뷰 초기화
        for(int i = 0; i < al.size();) {
            al.remove(i);
        }

        MyAdapter adapter_list = new MyAdapter(
                getApplicationContext(), // 현재화면의 제어권자
                R.layout.item,
                al);

        // adapterView - ListView, GridView
        ListView lv = (ListView)findViewById(R.id.list);
        lv.setAdapter(adapter_list);

        // 리스트뷰 갱신
        try {
            // Ok싸인 까지
            GlobalSocket.out.write(("SEARCH/" + "foodstyleInpo" + "/" + foodstyleInpo2 + "/" + "REGION" + "/" + areaInpo2 + "/").getBytes());
            byte[] instrA;
            String str = "";
            String str1 = "";
            //GlobalSocket.readThread.start();
            while (GlobalSocket.bBufferLength <= 0) {

            }
            instrA = new byte[GlobalSocket.bBufferLength];
            instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
            str = new String(instrA, "CP949");
            GlobalSocket.bBufferLength = 0;
            GlobalSocket.dataSize = 0;
            imageArr = null;
            GlobalSocket.out.write("READY".getBytes());
            while (GlobalSocket.bBufferLength <= 0) {

            }
            instrA = new byte[GlobalSocket.bBufferLength];
            instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
            str = new String(instrA, "CP949");
            GlobalSocket.bBufferLength = 0;
            GlobalSocket.dataSize = 0;
            imageArr = null;
            if(str.equals("SEARCHEND"))
            {
                GlobalSocket.out.write("END".getBytes());
                lv.setAdapter(adapter_list);

                return;
            }
            GlobalSocket.out.write("OK".getBytes());
            int strInt = Integer.parseInt(str);

            for(int i = 0; i < strInt; i ++)
            {
                while (GlobalSocket.bBufferLength <= 0) {

                }
                instrA = new byte[GlobalSocket.bBufferLength];
                instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
                str = new String(instrA, "CP949");
                GlobalSocket.bBufferLength = 0;
                GlobalSocket.dataSize = 0;
                String[] data = str.split("/");
                //al.add(new Story(data[2], data[5], data[6], data[7], data[0], R.drawable.icon));
                imageArr = null;
                GlobalSocket.out.write("OK".getBytes());

                while (GlobalSocket.bBufferLength <= 0) {
                }

                instrA = new byte[GlobalSocket.bBufferLength];
                instrA = Arrays.copyOf(GlobalSocket.byteBuffer, GlobalSocket.bBufferLength);
                str = new String(instrA, "CP949");
                GlobalSocket.bBufferLength = 0;
                GlobalSocket.dataSize = 0;
                int byteLength = Integer.parseInt(str);
                imageArr = new byte[byteLength];
                int dataLength = 0;
                GlobalSocket.out.write("OK".getBytes());

                while(GlobalSocket.dataSize < byteLength) {
                }

                Bitmap realimage = BitmapFactory.decodeByteArray(imageArr , 0 , imageArr.length);
                GlobalSocket.bBufferLength = 0;
                GlobalSocket.dataSize = 0;
                // 날짜 + 작성자 + 음식이름 + 종류 + 지역 + 가격 + 위치정보 + 평가 //
                // 리스트 뷰에 추가
                al.add(new Story(data[4], data[3] ,data[2], data[5], data[6], data[7], data[0] + "에 " + data[1] + "님이 작성한 글 입니다.", realimage));
                imageArr = null;
                GlobalSocket.out.write("OK".getBytes());
            }

            lv.setAdapter(adapter_list);

            GlobalSocket.bBufferLength = 0;
            GlobalSocket.dataSize = 0;
            imageArr = null;
        }
        catch (IOException e) {
            System.out.println("bitmapErr: " + e);
        }
    }

    // 작성 버튼
    public void writebutton2(View v) {
        Intent intent = new Intent(list.this, write.class);
        startActivity(intent);
    }
}


// 리스트뷰 커스텀 어댑터 //
class MyAdapter extends BaseAdapter {
    Context context;
    int layout;
    ArrayList<Story> al;
    LayoutInflater inf;
    public MyAdapter(Context context, int layout, ArrayList<Story> al) {
        this.context = context;
        this.layout = layout;
        this.al = al;
        this.inf = (LayoutInflater) context.getSystemService
                (Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() { // 총 데이터의 개수
        return al.size();
    }
    @Override
    public Object getItem(int position) { // 해당 행의 데이터
        return al.get(position);
    }
    @Override
    public long getItemId(int position) { // 해당 행의 유니크한 id
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = inf.inflate(layout, null);

        TextView tv1 = (TextView) convertView.findViewById(R.id.textView1); // food
        TextView tv2 = (TextView) convertView.findViewById(R.id.textView2); // price
        TextView tv3 = (TextView) convertView.findViewById(R.id.textView3); // location
        TextView tv4 = (TextView) convertView.findViewById(R.id.textView4); // comment
        TextView tv5 = (TextView) convertView.findViewById(R.id.textView5); // data + writer
        TextView tv6 = (TextView) convertView.findViewById(R.id.textView6); // region
        TextView tv7 = (TextView) convertView.findViewById(R.id.textView7); // foodstyle

        ImageView iv = (ImageView) convertView.findViewById(R.id.imageView1); // 지이미


        Story s = al.get(position);
        tv1.setText(s.foodname);
        tv2.setText(s.price);
        tv3.setText(s.location);
        tv4.setText(s.comment);
        tv5.setText(s.data);
        tv6.setText(s.region);
        tv7.setText(s.foodstyle);
        iv.setImageBitmap(s.img);
        //iv.setImageResource(s.img);
        return convertView;
    }
}

class Story { // 자바빈
    String foodname = "";
    String price = "";
    String location = "";
    String comment = "";
    String data = "";
    String foodstyle = "";
    String region = "";
    Bitmap img; // 이미지
    public Story(String foodstyle , String region , String foodname, String price , String location, String comment , String data , Bitmap img) {
        this.foodname = foodname;
        this.price = price;
        this.location = location;
        this.comment = comment;
        this.data = data;
        this.foodstyle = foodstyle;
        this.region = region;
        this.img = img;

    }
    public Story() {} // 기본생성자 : 생성자 작업시 함께 추가하자
}